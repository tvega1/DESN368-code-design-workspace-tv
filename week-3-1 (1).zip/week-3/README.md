
# Week 3 

## CodePen Links

Submit your completed CodePen links below:

**Intro to CSS Exercises:**

1. 01-css-methods: (https://codepen.io/tmasingale/pen/JoGOjOb)
2. 02-class-id-selectors: [Your CodePen link here]
3. 03-grouping-selectors: [Your CodePen link here]
4. 04-chaining-selectors: [Your CodePen link here]
5. 05-descendant-combinator: [Your CodePen link here]

**Cascade Exercise:** 6. 01-cascade-fix: [Your CodePen link here]
